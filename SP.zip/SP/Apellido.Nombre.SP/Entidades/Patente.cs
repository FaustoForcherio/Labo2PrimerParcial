﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Patente
    {
        private string _codigoPatente;
        private Tipo _tipoCodigo;

        public Patente() { }

        public Patente(string codigoPatente, Tipo tipoCodigo)
        {
            _codigoPatente = codigoPatente;
            _tipoCodigo = tipoCodigo;
        }

        public string CodigoPatente { get => _codigoPatente; set => _codigoPatente = value; }
        public Tipo TipoCodigo { get => _tipoCodigo; set => _tipoCodigo = value; }

        public override string ToString()
        {
            return _codigoPatente;
        }
    }
}
