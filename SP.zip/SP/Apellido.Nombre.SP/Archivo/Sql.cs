﻿using Entidades;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;

namespace Archivo
{
    public class Sql :IArchivo
    {
        private SqlConnection _conexion;
        private SqlCommand _comando;

        public Sql() {
            this._conexion = new SqlConnection(@"Data Source = Fausto\SQLEXPRESS;Database = lab_sp;Trusted_Connection = True;");
            this._comando = new SqlCommand();
            _comando.CommandType = CommandType.Text;
            _comando.Connection = _conexion;

        }
        public bool Guardar(List<Patente> datos) {
            try {
                _conexion.Open();
                using (_comando)
                {
                    _comando.CommandText = "INSERT INTO patentes (patente, tipo)" + $" VALUES (@patente, @tipo)";
                    foreach (Patente dato in datos)
                    {
                        _comando.Parameters.AddWithValue("@patente", dato.CodigoPatente);
                        _comando.Parameters.AddWithValue("@tipo", dato.TipoCodigo.ToString());
                        _comando.ExecuteNonQuery();
                        _comando.Parameters.Clear();

                    }
                    return true;

                }
            }
            catch (Exception)
            {
                return false;
            }
        }

        public List<Patente> Leer() {
            _comando.CommandText = "SELECT * FROM patentes";
            _conexion.Open();
            List<Patente> lista = new List<Patente>();
            using (SqlDataReader reader = _comando.ExecuteReader())
            {
                while (reader.Read()) {
                    lista.Add(new Patente(reader["patente"].ToString(), (Tipo)reader["tipo"]));
                

                }

            }
                return lista;
        }

    }
}
