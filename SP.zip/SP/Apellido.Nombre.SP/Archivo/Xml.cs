﻿using Entidades;
using System;
using System.Collections.Generic;
using System.IO;
using System.Xml.Serialization;

namespace Archivo
{
    [XmlInclude(typeof(Patente))]
    public class Xml : IArchivo
    {
        string rutaEscritorio = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), "Patente.xml");
        public bool Guardar(List<Patente> datos)
        {
            try
            {
                XmlSerializer xmlSerializer = new XmlSerializer(typeof(List<Patente>));
                using (StreamWriter streamWriter = new StreamWriter(rutaEscritorio))
                {
                    xmlSerializer.Serialize(streamWriter, datos);
                    return true;
                }

            }
            catch (Exception)
            {

                return false;
            }


        }

        public List<Patente> Leer() {
            List<Patente> lista = new List<Patente>();
            try
            {
                using (StreamReader streamReader = new StreamReader(rutaEscritorio))
                {
                    XmlSerializer xmlSerializer = new XmlSerializer(typeof(List<Patente>));
                    lista = (List<Patente>)xmlSerializer.Deserialize(streamReader);
                    return lista;
                }

            }
            catch (Exception)
            {

                return null;

            }


        }
    }
}
