﻿using Entidades;
using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.CompilerServices;

namespace Archivo
{
    public class Texto : IArchivo
    {
        string rutaEscritorio = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop),"Patente.txt");

        public bool Guardar(List<Patente> datos) {
            try
            {
                if (!File.Exists(rutaEscritorio))
                {
                    using (FileStream fileStream = File.Create(rutaEscritorio))
                    {


                        fileStream.Close();
                    }
                }

                using (StreamWriter streamWriter = new StreamWriter(rutaEscritorio))
                {
                    foreach (Patente patente in datos)
                    {
                        streamWriter.WriteLine(patente.ToString());
                    }
                    return true;
                }
            }
            catch(Exception) { 
                return false;
            }

        }
        public List<Patente> Leer()
        {
            List<Patente> lista = new List<Patente>();
            Patente aux = new Patente();
            try
            {

                if (File.Exists(rutaEscritorio))
                {
                    using (StreamReader streamReader = File.OpenText(rutaEscritorio))
                    {
                        
                        foreach (string linea in File.ReadLines(rutaEscritorio))
                        {

                            aux.CodigoPatente = linea;
                            lista.Add(aux);
                        }

                        return lista;
                    }
                }
            }
            catch (Exception)
            {
                throw new Exception("No se pudo leer el archivo");
            }
            return null;
        }
    }
}
