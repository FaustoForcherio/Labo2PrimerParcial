﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using Entidades;
using Archivo;
using System.Threading;
using Patentes;

namespace Formulario
{
    /// <summary>
    /// Formulario principal para la gestión de patentes.
    /// </summary>
    public partial class FrmPricipal : Form
    {
        List<Patente> patentes;
        List<Thread> listaT;

        /// <summary>
        /// Inicializa una nueva instancia de la clase <see cref="FrmPricipal"/>.
        /// </summary>
        public FrmPricipal()
        {
            InitializeComponent();
            patentes = new List<Patente>();
            listaT = new List<Thread>();
        }

        /// <summary>
        /// Manejador del evento Load del formulario.
        /// </summary>
        /// <param name="sender">El origen del evento.</param>
        /// <param name="e">Los datos del evento.</param>
        private void FrmPricipal_Load(object sender, EventArgs e)
        {
            vistaPatente.finExposicion += ProximaPatente;
        }

        /// <summary>
        /// Manejador del evento FormClosing del formulario.
        /// </summary>
        /// <param name="sender">El origen del evento.</param>
        /// <param name="e">Los datos del evento.</param>
        private void FrmPricipal_FormClosing(object sender, FormClosingEventArgs e)
        {
            FinalizarSimulacion();

        }

        /// <summary>
        /// Manejador del evento Click del botón para agregar más patentes.
        /// </summary>
        /// <param name="sender">El origen del evento.</param>
        /// <param name="e">Los datos del evento.</param>
        private void btnMas_Click(object sender, EventArgs e)
        {
            Sql _sql = new Sql();
            Xml xml = new Xml();
            Texto txt = new Texto();

            try
            {
                List<Patente> listPatente = new List<Patente>
                {
                    new Patente("CP709WA", Tipo.Mercosur),
                    new Patente("DIB009", Tipo.Vieja),
                    new Patente("FD010GC", Tipo.Mercosur)
                };

                if (_sql.Guardar(listPatente))
                {
                    MessageBox.Show(" “¡Patentes guardadas en la base de\r\ndatos!");
                }
                else
                {
                    MessageBox.Show("¡Error al guardar en la base de datos!");
                }
                if (xml.Guardar(listPatente))
                {
                    MessageBox.Show("¡Patentes guardadas en el archivo\r\nxml!");
                }
                else
                {
                    MessageBox.Show("¡Error al guardar en el archivo xml!");
                }
                if (txt.Guardar(listPatente))
                {
                    MessageBox.Show("¡Patentes guardadas en el archivo!");
                }
                else
                {
                    MessageBox.Show("¡Error al guardar en el archivo!");
                }
                // Implementar acá el punto del botón +
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        /// <summary>
        /// Manejador del evento Click del botón para leer patentes desde la base de datos SQL.
        /// </summary>
        /// <param name="sender">El origen del evento.</param>
        /// <param name="e">Los datos del evento.</param>
        private void btnSql_Click(object sender, EventArgs e)
        {
            try
            {
                Sql _sql = new Sql();
                patentes = _sql.Leer();
                IniciarSimulacion();

            }
            catch (Exception ex)
            {

                throw new Exception(ex.Message);
            }

        }

        /// <summary>
        /// Manejador del evento Click del botón para leer patentes desde un archivo XML.
        /// </summary>
        /// <param name="sender">El origen del evento.</param>
        /// <param name="e">Los datos del evento.</param>
        private void btnXml_Click(object sender, EventArgs e)
        {
            try
            {
                Xml xml = new Xml();
                patentes = xml.Leer();
                IniciarSimulacion();
            }
            catch (Exception ex) { 
            
                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// Manejador del evento Click del botón para leer patentes desde un archivo de texto.
        /// </summary>
        /// <param name="sender">El origen del evento.</param>
        /// <param name="e">Los datos del evento.</param>
        private void btnTxt_Click(object sender, EventArgs e)
        {
            try { 
                Texto txt = new Texto();
                patentes = txt.Leer();
                IniciarSimulacion();
            }
            catch (Exception ex)
            {

                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// Inicia la simulación de visualización de patentes.
        /// </summary>
        private void IniciarSimulacion()
        {
            // Implementar el método FinalizarSimulación
            // que se encarga de finalizar todos los hilos activos
            FinalizarSimulacion();
            ProximaPatente(vistaPatente);
        }

        private void FinalizarSimulacion()
        {
            if (listaT.Any())
            {

                foreach (var thread in listaT)
                {
                    if (thread.IsAlive)
                    {
                        thread.Abort();
                    }
                }
            }

        }

        /// <summary>
        /// Muestra la próxima patente en la vista.
        /// </summary>
        /// <param name="vistaPatente">La vista de la patente.</param>
        private void ProximaPatente(Patentes.VistaPatente vistaPatente)
        {
            if (patentes.Count > 0)
            {
                //Inicializará el hilo recién creado con el próximo elemento de la lista(tomar el
                //primero y eliminarlo una vez agregado al hilo).

                Thread thread = new Thread(new ParameterizedThreadStart(vistaPatente.MostrarPatente));
                thread.Start(patentes.First());
                listaT.Add(thread);
                patentes.RemoveAt(0);


                //Implementar acá el manejo de hilos
            }
        }
    }
}
